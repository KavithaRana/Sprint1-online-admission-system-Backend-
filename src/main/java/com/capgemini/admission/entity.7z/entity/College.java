package com.capgemini.admission.entity;

import java.io.Serializable;
import java.util.ArrayList;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "colleges")
public class College implements Serializable {
	@Id
	private int collegeRegId;
	private String collegeName;
	@OneToMany(mappedBy = "college")
	ArrayList<Branch> branchList = new ArrayList<Branch>();
	ArrayList<Course> courseList = new ArrayList<Course>();

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "university_id")
	private University university;

	public College() {
		super();
		// TODO Auto-generated constructor stub
	}

	public College(int collegeRegId, String collegeName, ArrayList<Branch> branchList, ArrayList<Course> courseList,
			University university) {
		super();
		this.collegeRegId = collegeRegId;
		this.collegeName = collegeName;
		this.branchList = branchList;
		this.courseList = courseList;
		this.university = university;
	}

	public int getCollegeRegId() {
		return collegeRegId;
	}

	public void setCollegeRegId(int collegeRegId) {
		this.collegeRegId = collegeRegId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public ArrayList<Branch> getBranchList() {
		return branchList;
	}

	public void setBranchList(ArrayList<Branch> branchList) {
		this.branchList = branchList;
	}

	public ArrayList<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}

	public University getUniversity() {
		return university;
	}

	public void setUniversity(University university) {
		this.university = university;
	}

}
