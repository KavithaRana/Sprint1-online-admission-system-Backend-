package com.capgemini.admission.entity;

import java.io.Serializable;
import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "universities")
public class University implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String name;
	@Id
	public int universityId;
	@OneToMany(mappedBy = "university")
	public ArrayList<College> collegeList = new ArrayList<College>();

	public University() {
		super();
		// TODO Auto-generated constructor stub
	}

	public University(String name, int universityId, ArrayList<College> collegeList) {
		super();
		this.name = name;
		this.universityId = universityId;
		this.collegeList = collegeList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getUniversityId() {
		return universityId;
	}

	public void setUniversityId(int universityId) {
		this.universityId = universityId;
	}

	public ArrayList<College> getCollegeList() {
		return collegeList;
	}

	public void setCollegeList(ArrayList<College> collegeList) {
		this.collegeList = collegeList;
	}

}
