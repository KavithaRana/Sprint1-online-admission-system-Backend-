package com.capgemini.admission.entity;

import java.io.Serializable;
import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "courses")
public class Course implements Serializable {
	@Id
	private int courseId;
	private String courseName;
	private String eligibity;
	private College college;
	@OneToMany(mappedBy = "course", fetch = FetchType.EAGER)
	private ArrayList<Branch> branches = new ArrayList<Branch>();

	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Course(int courseId, String courseName, String eligibity, College college, ArrayList<Branch> branches) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.eligibity = eligibity;
		this.college = college;
		this.branches = branches;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getEligibity() {
		return eligibity;
	}

	public void setEligibity(String eligibity) {
		this.eligibity = eligibity;
	}

	public College getCollege() {
		return college;
	}

	public void setCollege(College college) {
		this.college = college;
	}

	public ArrayList<Branch> getBranches() {
		return branches;
	}

	public void setBranches(ArrayList<Branch> branches) {
		this.branches = branches;
	}

}
