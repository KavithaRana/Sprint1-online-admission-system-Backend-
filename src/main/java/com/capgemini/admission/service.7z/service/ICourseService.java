package com.capgemini.admission.service;

import java.util.ArrayList;

import com.capgemini.admission.entity.Branch;
import com.capgemini.admission.entity.Course;

public interface ICourseService {
	public Course addCourse(Course course);
	public ArrayList<Branch>viewAllBranchDetails();
	public Branch getBranchById(int branchId);
	public int deleteBranchById(int branchId);
	public int updateBranch(Branch branch);

}
