package com.capgemini.admission.service;

import java.util.ArrayList;

import com.capgemini.admission.entity.Application;

public interface IApplicationService {

	public ArrayList<Application> viewAllApplicationDetails();

	public ArrayList<Application> getApplicationDetailsByEmail(String email);

	public Application addApplication(Application application);

	public int deleteApplicationById(int applicationId);

	public int deleteApplicationByEmail(String email);

	public Application getApplicationById(int applicationId);

	public int updateApplicationStatus(Application app);

}
