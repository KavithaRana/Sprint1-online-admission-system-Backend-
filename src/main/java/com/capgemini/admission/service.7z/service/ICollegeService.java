package com.capgemini.admission.service;

import java.util.ArrayList;

import com.capgemini.admission.entity.College;

public interface ICollegeService {
	public College addCollege(College college);
	public ArrayList<College> viewAllCollegeDetails();
	public int deleteCollegeById(int collegeId);
	public int updateCollegeDetails(College college);
	public College getCollegeDetailsById(int collegeId);
	

}
