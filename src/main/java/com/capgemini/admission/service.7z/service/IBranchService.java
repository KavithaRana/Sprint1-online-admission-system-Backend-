package com.capgemini.admission.service;

import java.util.ArrayList;

import com.capgemini.admission.entity.Branch;

public interface IBranchService {
	public Boolean addBranch(Branch branch);
	public ArrayList<Branch> viewAllBranchDetails();
	public ArrayList<Branch> getBranchDetailsByName(String branchName);
	public int deleteBranchById(int branchId);
	public Branch getBranchById(int branchId);
	public int deleteBranchByName(String branchName);
	public int updateBranch(Branch branch);

}
