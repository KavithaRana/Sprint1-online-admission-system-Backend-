package com.capgemini.admission.service;

public interface ILoginService {

}
